var codeComData = {
    "Sheet1": [
        {
            "Code Base Details": "Total SQL Scripts",
            "undefined": "812"
        },
        {
            "Code Base Details": "Total Tables",
            "undefined": "4565"
        },
        {
            "Code Base Details": "Total Views",
            "undefined": "392"
        },
        {
            "Code Base Details": "Total Materialized Views",
            "undefined": "0"
        },
        {
            "Code Base Details": "Total Indicies",
            "undefined": "10"
        },
        {
            "Code Base Details": "Total Packages",
            "undefined": "1"
        },
        {
            "Code Base Details": "Total Procedures",
            "undefined": "783"
        },
        {
            "Code Base Details": "Total Functions",
            "undefined": "31"
        },
        {
            "Code Base Details": "Total Triggers",
            "undefined": "0"
        },
        {
            "Code Base Details": "Total Dynamic SQL Calls",
            "undefined": "3138"
        },
        {
            "Code Base Details": "Total Loops & Cursors",
            "undefined": "71"
        },
        {
            "Code Base Details": "Total Conditionals",
            "undefined": "381"
        },
        {
            "Code Base Details": "Total Lines of Code",
            "undefined": "341673"
        },
        {
            "Code Base Details": "Job Complexity Categorization"
        },
        {
            "Code Base Details": "LOW",
            "undefined": "649"
        },
        {
            "Code Base Details": "MEDIUM",
            "undefined": "144"
        },
        {
            "Code Base Details": "HIGH",
            "undefined": "19"
        }
    ]
}