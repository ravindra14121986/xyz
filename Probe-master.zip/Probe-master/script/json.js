var adminObj = [
{"EMail": "admin@cg.com", "Password": "Admin01$"},
  {"EMail": "vasu@cg.com", "Password": "Vasu01$"}
  
  
];

var clientObj = [
{"EMail": "dilip@cg.com", "Password": "Dilip01$"},
  {"EMail": "devang@cg.com", "Password": "Devang0$"}
  
  
];
 
